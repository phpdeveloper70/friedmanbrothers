<!--Footer-part-->
<div class="row-fluid">
   <div id="footer" class="span12"> <?php echo date('Y') ?> &copy; <b>Graphics Merlin Studio Pvt Ltd</b>.</div>
</div>
<!--end-Footer-part-->
<script src="<?php echo base_url('assets/admin/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.ui.custom.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.uniform.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/select2.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/matrix.js'); ?>"></script>
<script src="<?php echo base_url('assets/admin/js/matrix.tables.js'); ?>"></script>
